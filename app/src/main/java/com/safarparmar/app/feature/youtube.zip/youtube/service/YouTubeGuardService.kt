package com.safarparmar.app.feature.youtube.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.safarparmar.app.feature.youtube.detector.YouTubeSnapshot
import com.safarparmar.app.feature.youtube.detector.YouTubeSnapshotParser
import com.safarparmar.app.feature.youtube.overlay.YouTubeGuardOverlayManager
import com.safarparmar.app.feature.youtube.policy.PolicyState
import com.safarparmar.app.feature.youtube.policy.YouTubePolicyEngine
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Accessibility service that monitors YouTube for content policy enforcement.
 *
 * Watches only [YOUTUBE_PACKAGE], parses the UI tree into a [YouTubeSnapshot] on every
 * window-content-change event, and delegates to [YouTubePolicyEngine] for blocking decisions.
 * The overlay is rendered by [YouTubeGuardOverlayManager] using TYPE_ACCESSIBILITY_OVERLAY.
 */
@AndroidEntryPoint
class YouTubeGuardService : AccessibilityService() {

    @Inject lateinit var policyEngine: YouTubePolicyEngine
    @Inject lateinit var overlayManager: YouTubeGuardOverlayManager

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var lastSnapshot: YouTubeSnapshot = YouTubeSnapshot.EMPTY

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Provide the Service context to the overlay manager for WindowManager token binding
        overlayManager.onServiceConnected(this)

        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_VIEW_SCROLLED
            packageNames = arrayOf(YOUTUBE_PACKAGE)
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            notificationTimeout = EVENT_DEBOUNCE_MS
        }

        observePolicyState()
        Log.d(TAG, "YouTubeGuardService connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return

        // If an event occurs outside YouTube, hide the overlay and stop verification
        if (event.packageName?.toString() != YOUTUBE_PACKAGE) {
            return
        }

        serviceScope.launch(Dispatchers.Default) {
            val root = rootInActiveWindow
            if (root == null) {
                Log.d(TAG, "rootInActiveWindow is null — skipping event")
                return@launch
            }

            val snapshot: YouTubeSnapshot
            try {
                snapshot = YouTubeSnapshotParser.parse(root)
            } catch (e: Exception) {
                Log.e(TAG, "Snapshot parse error", e)
                root.recycle()
                return@launch
            }
            root.recycle()

            // Avoid redundant evaluations for identical snapshots
            if (snapshot == lastSnapshot) return@launch
            lastSnapshot = snapshot

            // If no video or Shorts is detected, user is in home feed, library, or search
            if (snapshot.channelHandle.isBlank() && snapshot.channelName.isBlank() && !snapshot.isShorts) {
                Log.d(TAG, "No video or Shorts active — stopping playback policy")
                policyEngine.onPlaybackStopped()
                overlayManager.hide()
                return@launch
            }

            // A video or Shorts is active: evaluate with policy engine
            policyEngine.onVideoDetected(snapshot.toVideoIdentity())
        }
    }

    override fun onInterrupt() {
        overlayManager.hide()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        policyEngine.onPlaybackStopped()
        overlayManager.onServiceDestroyed()
        serviceScope.cancel()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        serviceScope.cancel()
        overlayManager.onServiceDestroyed()
        super.onDestroy()
    }

    // ---------------------------------------------------------------------------
    // Private helpers
    // ---------------------------------------------------------------------------

    private fun observePolicyState() {
        policyEngine.state
            .onEach { state -> handlePolicyState(state) }
            .launchIn(serviceScope)
    }

    private fun handlePolicyState(state: PolicyState) {
        Log.d(TAG, "Policy state → $state")
        when (state) {
            is PolicyState.Allowed -> overlayManager.hide()

            // Verifying is an internal ~2ms DB check state — do not flash overlay
            is PolicyState.Verifying -> overlayManager.hide()

            is PolicyState.Blocked -> overlayManager.showBlocked(
                channelName = state.identity.channelName.ifBlank { state.channelHandle },
                channelHandle = state.channelHandle,
                reason = state.reason,
                onBack = { performGlobalAction(GLOBAL_ACTION_BACK) },
            )

            is PolicyState.ShortsBlocked -> overlayManager.showShortsBlocked(
                onBack = { performGlobalAction(GLOBAL_ACTION_BACK) },
            )

            is PolicyState.AskUser -> overlayManager.showAskUser(
                channelName = state.identity.channelName.ifBlank { state.channelHandle },
                channelHandle = state.channelHandle,
                onClassify = { handle, policy ->
                    policyEngine.onUserClassified(handle, policy)
                },
                onBack = { performGlobalAction(GLOBAL_ACTION_BACK) },
            )
        }
    }

    companion object {
        private const val TAG = "YouTubeGuard"
        const val YOUTUBE_PACKAGE = "com.google.android.youtube"
        private const val EVENT_DEBOUNCE_MS = 300L
    }
}
