package com.safarparmar.app.feature.youtube.detector

import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Parses an AccessibilityNodeInfo tree from the YouTube app into a clean [YouTubeSnapshot].
 *
 * Designed to work across modern YouTube app versions (including Litho / Compose node trees
 * where traditional resource-ids may be absent):
 * 1. Shorts detection: checks Remix button, selected Shorts tab, reel scrim/timebar view IDs,
 *    and Shorts-specific text patterns.
 * 2. Channel & handle extraction: parses "Subscribe to <Channel>", "<Channel> <Count> subscribers",
 *    and inline @handles from text and content descriptions.
 * 3. In-stream Ad detection: checks explicit ad badge view IDs and "Ad ·" prefixes strictly in
 *    the active player area, avoiding feed recommendation ads or buttons like "Add to playlist".
 */
object YouTubeSnapshotParser {

    private const val TAG = "YouTubeGuard"
    private const val YT_PKG = "com.google.android.youtube:id/"

    // --- In-Stream Ad IDs (within player only) ---
    private val IN_STREAM_AD_IDS = setOf(
        "${YT_PKG}skip_ad_button",
        "${YT_PKG}ad_skip_button",
        "${YT_PKG}skip_next_button",
        "${YT_PKG}ad_badge",
        "${YT_PKG}ad_text_badge",
        "${YT_PKG}ad_countdown",
    )

    // --- Title IDs ---
    private val TITLE_IDS = setOf(
        "${YT_PKG}title",
        "${YT_PKG}video_title",
        "${YT_PKG}watch_video_title",
        "${YT_PKG}reel_watch_player_title",
        "${YT_PKG}player_view_title",
        "${YT_PKG}playlist_name",
    )

    // --- Channel name IDs ---
    private val CHANNEL_NAME_IDS = setOf(
        "${YT_PKG}channel_name",
        "${YT_PKG}uploader_name",
        "${YT_PKG}author",
        "${YT_PKG}creator_name",
        "${YT_PKG}reel_channel_name",
        "${YT_PKG}channel_button",
    )

    // Regex patterns for modern YouTube accessibility descriptions
    private val SUBSCRIBE_TO_REGEX = Regex("""^Subscribe to (.+?)\.?$""", RegexOption.IGNORE_CASE)
    private val SUBSCRIBERS_REGEX = Regex("""^(.+?)\s+\d+([.,]\d+)?\s*[KMBkmb]?\s+subscribers""", RegexOption.IGNORE_CASE)

    /**
     * Parse the root [AccessibilityNodeInfo] into a [YouTubeSnapshot].
     */
    fun parse(root: AccessibilityNodeInfo?): YouTubeSnapshot {
        if (root == null) return YouTubeSnapshot.EMPTY

        val allNodes = mutableListOf<AccessibilityNodeInfo>()
        collectNodes(root, allNodes)

        Log.d(TAG, "Parsing tree: ${allNodes.size} nodes")

        val isShorts = detectShorts(allNodes)
        val isAd = detectInStreamAd(allNodes)

        var title = extractByIds(allNodes, TITLE_IDS)
        var channelName = extractByIds(allNodes, CHANNEL_NAME_IDS)
        var channelHandle = extractChannelHandle(allNodes)

        // Fallback: modern YouTube uses contentDescription on Subscribe and Subscriber views
        if (channelName.isBlank()) {
            channelName = extractChannelNameFromDescriptions(allNodes)
        }

        // Synthesize handle from channelName if no explicit @handle was present
        if (channelHandle.isBlank() && channelName.isNotBlank()) {
            channelHandle = if (channelName.startsWith("@")) {
                channelName.lowercase()
            } else {
                "@${channelName.trim().replace("\\s+".toRegex(), "").lowercase()}"
            }
        }

        // If title is blank, search for candidate text in top half of screen
        if (title.isBlank()) {
            title = extractFallbackTitle(allNodes)
        }

        val confidence = when {
            channelHandle.isNotBlank() && title.isNotBlank() -> DetectionConfidence.HIGH
            channelName.isNotBlank() || channelHandle.isNotBlank() -> DetectionConfidence.MEDIUM
            isShorts -> DetectionConfidence.MEDIUM
            title.isNotBlank() -> DetectionConfidence.LOW
            else -> DetectionConfidence.UNKNOWN
        }

        Log.d(
            TAG,
            "Parsed: title='$title' channel='$channelName' handle='$channelHandle' " +
                "isShorts=$isShorts isAd=$isAd confidence=$confidence",
        )

        allNodes.forEach { runCatching { it.recycle() } }

        return YouTubeSnapshot(
            title = title,
            channelName = channelName,
            channelHandle = channelHandle,
            isShorts = isShorts,
            isAd = isAd,
            confidence = confidence,
        )
    }

    // ---------------------------------------------------------------------------
    // Private helpers
    // ---------------------------------------------------------------------------

    private fun collectNodes(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        try {
            out.add(AccessibilityNodeInfo.obtain(node))
        } catch (_: Exception) {
            return
        }
        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            collectNodes(child, out)
            runCatching { child.recycle() }
        }
    }

    private fun extractByIds(nodes: List<AccessibilityNodeInfo>, ids: Set<String>): String {
        for (node in nodes) {
            if (node.viewIdResourceName in ids) {
                val text = node.text?.toString()?.trim()
                if (!text.isNullOrBlank()) return text
                val desc = node.contentDescription?.toString()?.trim()
                if (!desc.isNullOrBlank()) return desc
            }
        }
        return ""
    }

    private fun extractChannelHandle(nodes: List<AccessibilityNodeInfo>): String {
        for (node in nodes) {
            val text = node.text?.toString()?.trim()
            if (!text.isNullOrBlank() && text.startsWith("@") && !text.contains(" ") && text.length in 2..40) {
                return text.lowercase()
            }
            val desc = node.contentDescription?.toString()?.trim()
            if (!desc.isNullOrBlank() && desc.startsWith("@") && !desc.contains(" ") && desc.length in 2..40) {
                return desc.lowercase()
            }
        }
        return ""
    }

    private fun extractChannelNameFromDescriptions(nodes: List<AccessibilityNodeInfo>): String {
        for (node in nodes) {
            val desc = node.contentDescription?.toString()?.trim() ?: continue

            // "Subscribe to T-Series." or "Subscribe to @presidential."
            val subMatch = SUBSCRIBE_TO_REGEX.matchEntire(desc)
            if (subMatch != null) {
                val name = subMatch.groupValues[1].trim().removeSuffix(".")
                if (name.isNotBlank() && name.length in 2..35 &&
                    !name.contains("favorite", ignoreCase = true) &&
                    !name.contains("channel", ignoreCase = true) &&
                    !name.contains("notified", ignoreCase = true)
                ) {
                    return name
                }
            }

            // "T-Series 315M subscribers"
            val subsCountMatch = SUBSCRIBERS_REGEX.find(desc)
            if (subsCountMatch != null) {
                val name = subsCountMatch.groupValues[1].trim()
                if (name.isNotBlank() && name.length in 2..35 &&
                    !name.contains("favorite", ignoreCase = true) &&
                    !name.contains("channel", ignoreCase = true)
                ) {
                    return name
                }
            }
        }
        return ""
    }

    private fun extractFallbackTitle(nodes: List<AccessibilityNodeInfo>): String {
        // Look for title text or playlist mix title
        for (node in nodes) {
            val text = node.text?.toString()?.trim() ?: continue
            if (text.length in 8..150 && !text.startsWith("@") && !text.contains("subscribers", ignoreCase = true)) {
                // Avoid utility strings
                if (!text.equals("Shorts", ignoreCase = true) && !text.equals("Home", ignoreCase = true) &&
                    !text.equals("Subscriptions", ignoreCase = true) && !text.equals("You", ignoreCase = true)
                ) {
                    return text
                }
            }
        }
        return ""
    }

    /**
     * Highly robust Shorts detection covering multiple reliable signals.
     */
    private fun detectShorts(nodes: List<AccessibilityNodeInfo>): Boolean {
        for (node in nodes) {
            val text = node.text?.toString()?.trim() ?: ""
            val desc = node.contentDescription?.toString()?.trim() ?: ""
            val id = node.viewIdResourceName ?: ""

            // Signal 1: "Remix" button (unique to YouTube Shorts)
            if (desc.equals("Remix", ignoreCase = true) || text.equals("Remix", ignoreCase = true)) {
                Log.d(TAG, "Shorts detected via Remix button")
                return true
            }

            // Signal 2: Shorts tab in bottom navigation is currently selected
            if (node.isSelected && (desc.equals("Shorts", ignoreCase = true) || text.equals("Shorts", ignoreCase = true))) {
                Log.d(TAG, "Shorts detected via selected bottom nav Shorts tab")
                return true
            }

            // Signal 3: Reel-specific active playback resource IDs
            if (id.contains("reel_scrim_shorts", ignoreCase = true) ||
                id.contains("reel_player_page", ignoreCase = true) ||
                id.contains("reel_watch_player", ignoreCase = true)
            ) {
                Log.d(TAG, "Shorts detected via resource ID: $id")
                return true
            }

            // Signal 4: Shorts-specific descriptions
            if (desc.contains("Dislike this short", ignoreCase = true) ||
                desc.contains("Sound used in this short", ignoreCase = true)
            ) {
                Log.d(TAG, "Shorts detected via description: $desc")
                return true
            }
        }

        return false
    }

    /**
     * In-stream Ad detection strictly for ads playing in the active video player.
     * Ignores sponsored cards in the feed, recommendations below the video, or "Add" buttons.
     */
    private fun detectInStreamAd(nodes: List<AccessibilityNodeInfo>): Boolean {
        for (node in nodes) {
            val id = node.viewIdResourceName ?: ""
            if (id in IN_STREAM_AD_IDS) {
                Log.d(TAG, "In-stream Ad detected via badge ID: $id")
                return true
            }

            val text = node.text?.toString()?.trim() ?: ""
            // Strict match for in-stream ad overlay text (e.g., "Ad · 0:15", "Ad 1 of 2")
            if (text.startsWith("Ad ·") || text.startsWith("Ad 1 of") || text.startsWith("Ad 2 of") ||
                text.equals("Skip Ad", ignoreCase = true) || text.equals("Skip Ads", ignoreCase = true)
            ) {
                Log.d(TAG, "In-stream Ad detected via ad text: '$text'")
                return true
            }
        }
        return false
    }
}
