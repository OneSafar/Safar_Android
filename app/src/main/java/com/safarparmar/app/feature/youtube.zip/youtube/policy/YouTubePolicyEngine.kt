package com.safarparmar.app.feature.youtube.policy

import com.safarparmar.app.data.local.entity.ChannelPolicy
import com.safarparmar.app.domain.repository.YouTubeChannelRepository
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Deterministic state machine and policy engine governing YouTube content blocking.
 *
 * Core Invariants:
 * 1. Default to [PolicyState.Verifying] immediately on ANY video identity change (fail-closed before DB lookup).
 * 2. Shorts are evaluated and blocked independently of channel policy ([PolicyState.ShortsBlocked]).
 * 3. Ad transitions retain previous verified channel's policy instead of evaluating ad metadata.
 */
@Singleton
class YouTubePolicyEngine(
    private val repository: YouTubeChannelRepository,
    private val scope: CoroutineScope,
) {
    /**
     * Primary constructor for Hilt dependency injection.
     * Uses [SupervisorJob] with [Dispatchers.Default] for production execution.
     */
    @Inject
    constructor(repository: YouTubeChannelRepository) : this(
        repository = repository,
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default),
    )

    private val _state = MutableStateFlow<PolicyState>(PolicyState.Verifying(null))
    val state: StateFlow<PolicyState> = _state.asStateFlow()

    private var currentIdentity: VideoIdentity? = null
    private var lastVerifiedPolicy: ChannelPolicy? = null
    private var lastVerifiedChannel: String? = null
    private var activeJob: Job? = null

    /**
     * Called whenever video information is extracted from AccessibilityService or MediaSessionManager.
     */
    fun onVideoDetected(identity: VideoIdentity) {
        // Prevent duplicate processing if identical video is already resolved
        if (identity.isSameVideo(currentIdentity) && _state.value !is PolicyState.Verifying) {
            return
        }

        activeJob?.cancel()
        currentIdentity = identity

        // INVARIANT 1: Default to 'Verifying' immediately on ANY video identity change (fail-closed)
        _state.value = PolicyState.Verifying(identity)

        activeJob = scope.launch {
            resolvePolicy(identity)
        }
    }

    private suspend fun resolvePolicy(identity: VideoIdentity) {
        // INVARIANT 2: Shorts are evaluated and blocked independently of channel policy
        if (identity.isShorts) {
            _state.value = PolicyState.ShortsBlocked(identity, BlockReason.SHORTS)
            return
        }

        // INVARIANT 3: Ad transitions retain previous verified channel's policy instead of evaluating ad metadata
        if (identity.isAd) {
            when (lastVerifiedPolicy) {
                ChannelPolicy.PRODUCTIVE -> {
                    _state.value = PolicyState.Allowed(
                        identity = identity,
                        channelHandle = lastVerifiedChannel ?: identity.channelHandle,
                    )
                }
                ChannelPolicy.DISTRACTING -> {
                    _state.value = PolicyState.Blocked(
                        identity = identity,
                        channelHandle = lastVerifiedChannel ?: identity.channelHandle,
                        reason = BlockReason.DISTRACTING_CHANNEL,
                    )
                }
                null -> {
                    // No prior verified video in session: cold start into ad fails closed
                    _state.value = PolicyState.Blocked(
                        identity = identity,
                        channelHandle = identity.channelHandle,
                        reason = BlockReason.UNVERIFIED,
                    )
                }
            }
            return
        }

        // Standard Video: Look up classification in repository
        val handle = identity.channelHandle.trim().ifEmpty { identity.channelName.trim() }
        if (handle.isEmpty()) {
            // Cannot verify without channel identity; remain fail-closed in Verifying
            return
        }

        val policy = repository.getChannelPolicy(handle)
        when (policy) {
            ChannelPolicy.PRODUCTIVE -> {
                lastVerifiedPolicy = ChannelPolicy.PRODUCTIVE
                lastVerifiedChannel = handle
                _state.value = PolicyState.Allowed(identity, handle)
            }
            ChannelPolicy.DISTRACTING -> {
                lastVerifiedPolicy = ChannelPolicy.DISTRACTING
                lastVerifiedChannel = handle
                _state.value = PolicyState.Blocked(identity, handle, BlockReason.DISTRACTING_CHANNEL)
            }
            null -> {
                // Unknown channel: prompt user via Compose overlay
                _state.value = PolicyState.AskUser(identity, handle)
            }
        }
    }

    /**
     * Called when the user classifies an unclassified channel via the AskUser overlay dialog.
     */
    fun onUserClassified(channelHandle: String, policy: ChannelPolicy) {
        val current = currentIdentity

        // Only update active state if the classification corresponds to the current video
        val currentHandle = current?.channelHandle?.trim()?.ifEmpty { current?.channelName?.trim() }
        val matchesCurrent = current != null && (
            channelHandle.equals(currentHandle, ignoreCase = true) ||
            channelHandle.removePrefix("@").equals(currentHandle?.removePrefix("@"), ignoreCase = true) ||
            channelHandle.equals(current.channelName.trim(), ignoreCase = true)
        )

        scope.launch(start = CoroutineStart.UNDISPATCHED) {
            repository.saveChannelPolicy(
                channelHandle = channelHandle,
                channelName = if (matchesCurrent) current?.channelName ?: "" else "",
                policy = policy,
            )
        }

        if (matchesCurrent && current != null && !current.isShorts) {
            activeJob?.cancel()

            lastVerifiedPolicy = policy
            lastVerifiedChannel = channelHandle

            when (policy) {
                ChannelPolicy.PRODUCTIVE -> {
                    _state.value = PolicyState.Allowed(current, channelHandle)
                }
                ChannelPolicy.DISTRACTING -> {
                    _state.value = PolicyState.Blocked(current, channelHandle, BlockReason.DISTRACTING_CHANNEL)
                }
            }
        }
    }

    /**
     * Called when playback exits or YouTube stops playing.
     */
    fun onPlaybackStopped() {
        activeJob?.cancel()
        currentIdentity = null
        lastVerifiedPolicy = null
        lastVerifiedChannel = null
        _state.value = PolicyState.Verifying(null)
    }
}
