package com.safarparmar.app.feature.youtube.policy

/**
 * Represents the extracted metadata identity of a video playing in YouTube.
 */
data class VideoIdentity(
    val videoId: String? = null,
    val title: String = "",
    val channelHandle: String = "",
    val channelName: String = "",
    val isShorts: Boolean = false,
    val isAd: Boolean = false,
) {
    /**
     * Determines whether another [VideoIdentity] represents the identical playing content.
     * Distinguishes between video playback, ad playback, and shorts.
     */
    fun isSameVideo(other: VideoIdentity?): Boolean {
        if (other == null) return false
        if (!videoId.isNullOrBlank() && !other.videoId.isNullOrBlank()) {
            return videoId == other.videoId && isShorts == other.isShorts && isAd == other.isAd
        }
        return title == other.title &&
            channelHandle == other.channelHandle &&
            isShorts == other.isShorts &&
            isAd == other.isAd
    }
}
