# Safar Android Notification Icon

This package contains Android notification small-icon assets generated from your SVG.

Use:
- Vector drawable: app/src/main/res/drawable/ic_safar_notification.xml
- PNG fallbacks:
  - drawable-mdpi/ic_safar_notification.png 24x24
  - drawable-hdpi/ic_safar_notification.png 36x36
  - drawable-xhdpi/ic_safar_notification.png 48x48
  - drawable-xxhdpi/ic_safar_notification.png 72x72
  - drawable-xxxhdpi/ic_safar_notification.png 96x96

These are monochrome white icons with transparent backgrounds, suitable for Android notification small icons.
