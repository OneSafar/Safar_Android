package com.parmaracademy.safar.habits.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.DayOfWeek
import java.time.LocalDate

/**
 * A single trackable habit. May optionally belong to a [RoutineEntity]
 * (routineId != null) or stand alone (routineId == null).
 */
@Entity(
    tableName = "habits",
    foreignKeys = [
        ForeignKey(
            entity = RoutineEntity::class,
            parentColumns = ["id"],
            childColumns = ["routineId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("routineId")]
)
data class HabitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val routineId: Long? = null,
    @ColumnInfo(name = "target_days")
    val targetDays: Set<DayOfWeek> = DayOfWeek.entries.toSet(),
    val isActive: Boolean = true,
    val order: Int = 0
)

/** A named group of habits, e.g. "Morning routine". */
@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val order: Int = 0
)

/** One completion record for a habit on a given calendar date. */
@Entity(
    tableName = "habit_completions",
    primaryKeys = ["habitId", "date"],
    foreignKeys = [
        ForeignKey(
            entity = HabitEntity::class,
            parentColumns = ["id"],
            childColumns = ["habitId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("habitId"), Index("date")]
)
data class HabitCompletionEntity(
    val habitId: Long,
    val date: LocalDate,
    val completed: Boolean
)
