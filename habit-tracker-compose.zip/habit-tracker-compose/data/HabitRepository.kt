package com.parmaracademy.safar.habits.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.time.DayOfWeek
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HabitRepository @Inject constructor(
    private val dao: HabitDao
) {
    fun observeHabits(): Flow<List<HabitEntity>> = dao.observeActiveHabits()

    fun observeRoutines(): Flow<List<RoutineEntity>> = dao.observeRoutines()

    /** Habits scheduled for [date], joined with whether they're done that day. */
    fun observeForDate(date: LocalDate): Flow<List<HabitWithCompletion>> =
        combine(
            dao.observeActiveHabits(),
            dao.observeCompletionsForDate(date)
        ) { habits, completions ->
            val doneIds = completions.filter { it.completed }.map { it.habitId }.toSet()
            habits
                .filter { date.dayOfWeek in it.targetDays }
                .map { habit -> HabitWithCompletion(habit, date, habit.id in doneIds) }
        }

    /** Habits x each day in [start]..[end], for weekly/monthly grids. */
    fun observeForRange(start: LocalDate, end: LocalDate): Flow<List<HabitWithCompletions>> =
        combine(
            dao.observeActiveHabits(),
            dao.observeCompletionsBetween(start, end)
        ) { habits, completions ->
            val doneByHabit: Map<Long, Set<LocalDate>> = completions
                .filter { it.completed }
                .groupBy({ it.habitId }, { it.date })
                .mapValues { it.value.toSet() }

            habits.map { habit ->
                val dates = generateSequence(start) { it.plusDays(1) }.takeWhile { !it.isAfter(end) }
                val doneDates = doneByHabit[habit.id].orEmpty()
                HabitWithCompletions(
                    habit = habit,
                    completionByDate = dates.associateWith { it in doneDates }
                )
            }
        }

    suspend fun toggle(habitId: Long, date: LocalDate, currentlyDone: Boolean) {
        if (currentlyDone) {
            dao.clearCompletion(habitId, date)
        } else {
            dao.upsertCompletion(HabitCompletionEntity(habitId, date, completed = true))
        }
    }

    suspend fun createHabit(name: String, routineId: Long?, targetDays: Set<DayOfWeek>, order: Int) {
        dao.insertHabit(
            HabitEntity(name = name, routineId = routineId, targetDays = targetDays, order = order)
        )
    }

    suspend fun editHabit(habit: HabitEntity) = dao.updateHabit(habit)

    suspend fun deleteHabit(habit: HabitEntity) = dao.deleteHabit(habit)

    suspend fun createRoutine(name: String, order: Int): Long =
        dao.insertRoutine(RoutineEntity(name = name, order = order))

    suspend fun deleteRoutine(routine: RoutineEntity) = dao.deleteRoutine(routine)
}

data class HabitWithCompletion(
    val habit: HabitEntity,
    val date: LocalDate,
    val completed: Boolean
)

data class HabitWithCompletions(
    val habit: HabitEntity,
    /** date -> completed, for every day in the requested range. */
    val completionByDate: Map<LocalDate, Boolean>
)
