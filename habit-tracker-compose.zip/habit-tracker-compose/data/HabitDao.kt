package com.parmaracademy.safar.habits.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Dao
interface HabitDao {

    // --- Habits ---

    @Query("SELECT * FROM habits WHERE isActive = 1 ORDER BY `order` ASC")
    fun observeActiveHabits(): Flow<List<HabitEntity>>

    @Insert
    suspend fun insertHabit(habit: HabitEntity): Long

    @Update
    suspend fun updateHabit(habit: HabitEntity)

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)

    // --- Routines ---

    @Query("SELECT * FROM routines ORDER BY `order` ASC")
    fun observeRoutines(): Flow<List<RoutineEntity>>

    @Insert
    suspend fun insertRoutine(routine: RoutineEntity): Long

    @Delete
    suspend fun deleteRoutine(routine: RoutineEntity)

    // --- Completions ---

    /** Today: completion rows for a single date. */
    @Query("SELECT * FROM habit_completions WHERE date = :date")
    fun observeCompletionsForDate(date: LocalDate): Flow<List<HabitCompletionEntity>>

    /** Weekly / Monthly: completion rows for an inclusive date range. */
    @Query("SELECT * FROM habit_completions WHERE date BETWEEN :start AND :end")
    fun observeCompletionsBetween(start: LocalDate, end: LocalDate): Flow<List<HabitCompletionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCompletion(completion: HabitCompletionEntity)

    @Query("DELETE FROM habit_completions WHERE habitId = :habitId AND date = :date")
    suspend fun clearCompletion(habitId: Long, date: LocalDate)
}
