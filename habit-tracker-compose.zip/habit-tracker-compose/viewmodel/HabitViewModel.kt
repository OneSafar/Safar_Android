package com.parmaracademy.safar.habits.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.parmaracademy.safar.habits.data.HabitEntity
import com.parmaracademy.safar.habits.data.HabitRepository
import com.parmaracademy.safar.habits.data.HabitWithCompletion
import com.parmaracademy.safar.habits.data.HabitWithCompletions
import com.parmaracademy.safar.habits.data.RoutineEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import javax.inject.Inject

enum class HabitTab { TODAY, WEEKLY, MONTHLY }

data class HabitUiState(
    val routines: List<RoutineEntity> = emptyList(),
    val todayHabits: List<HabitWithCompletion> = emptyList(),
    val weeklyHabits: List<HabitWithCompletions> = emptyList(),
    val monthlyHabits: List<HabitWithCompletions> = emptyList(),
    val selectedDate: LocalDate = LocalDate.now(),
    val weekStart: LocalDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)),
    val monthAnchor: LocalDate = LocalDate.now().withDayOfMonth(1),
    val selectedTab: HabitTab = HabitTab.TODAY,
    val isLoading: Boolean = true
)

@HiltViewModel
class HabitViewModel @Inject constructor(
    private val repository: HabitRepository
) : ViewModel() {

    private val selectedTab = MutableStateFlow(HabitTab.TODAY)
    private val selectedDate = MutableStateFlow(LocalDate.now())
    private val weekStart = MutableStateFlow(
        LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    )
    private val monthAnchor = MutableStateFlow(LocalDate.now().withDayOfMonth(1))

    private val todayFlow = selectedDate.flatMapLatest { repository.observeForDate(it) }

    private val weeklyFlow = weekStart.flatMapLatest { start ->
        repository.observeForRange(start, start.plusDays(6))
    }

    private val monthlyFlow = monthAnchor.flatMapLatest { anchor ->
        val end = anchor.withDayOfMonth(anchor.lengthOfMonth())
        repository.observeForRange(anchor, end)
    }

    val uiState: StateFlow<HabitUiState> = combine(
        repository.observeRoutines(),
        todayFlow,
        weeklyFlow,
        monthlyFlow,
        selectedTab,
        selectedDate,
        weekStart,
        monthAnchor
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        HabitUiState(
            routines = values[0] as List<RoutineEntity>,
            todayHabits = values[1] as List<HabitWithCompletion>,
            weeklyHabits = values[2] as List<HabitWithCompletions>,
            monthlyHabits = values[3] as List<HabitWithCompletions>,
            selectedTab = values[4] as HabitTab,
            selectedDate = values[5] as LocalDate,
            weekStart = values[6] as LocalDate,
            monthAnchor = values[7] as LocalDate,
            isLoading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HabitUiState())

    fun selectTab(tab: HabitTab) {
        selectedTab.value = tab
    }

    fun toggleHabit(habitId: Long, date: LocalDate, currentlyDone: Boolean) {
        viewModelScope.launch { repository.toggle(habitId, date, currentlyDone) }
    }

    fun createHabit(name: String, routineId: Long?, targetDays: Set<DayOfWeek>) {
        viewModelScope.launch {
            val order = uiState.value.todayHabits.size
            repository.createHabit(name, routineId, targetDays, order)
        }
    }

    fun editHabit(habit: HabitEntity) {
        viewModelScope.launch { repository.editHabit(habit) }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch { repository.deleteHabit(habit) }
    }

    fun createRoutine(name: String) {
        viewModelScope.launch {
            val order = uiState.value.routines.size
            repository.createRoutine(name, order)
        }
    }

    fun deleteRoutine(routine: RoutineEntity) {
        viewModelScope.launch { repository.deleteRoutine(routine) }
    }

    fun changeWeek(forward: Boolean) {
        weekStart.value = weekStart.value.plusWeeks(if (forward) 1 else -1)
    }

    fun changeMonth(forward: Boolean) {
        monthAnchor.value = monthAnchor.value.plusMonths(if (forward) 1 else -1)
            .withDayOfMonth(1)
    }
}
