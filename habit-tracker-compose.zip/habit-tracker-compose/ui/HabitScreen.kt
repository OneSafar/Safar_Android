package com.parmaracademy.safar.habits.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.parmaracademy.safar.habits.viewmodel.HabitTab
import com.parmaracademy.safar.habits.viewmodel.HabitViewModel

@Composable
fun HabitScreen(
    viewModel: HabitViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var showAddHabit by remember { mutableStateOf(false) }
    var showAddRoutine by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = HabitColors.Background,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddHabit = true },
                containerColor = HabitColors.Surface,
                contentColor = HabitColors.TextPrimary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add habit")
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(HabitColors.Background)
                .padding(padding)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                androidx.compose.foundation.layout.Column(modifier = Modifier.fillMaxSize()) {
                    HabitTopTabs(
                        selected = state.selectedTab,
                        onSelect = viewModel::selectTab
                    )
                    when (state.selectedTab) {
                        HabitTab.TODAY -> TodayView(
                            date = state.selectedDate,
                            routines = state.routines,
                            habits = state.todayHabits,
                            onToggle = { id, done -> viewModel.toggleHabit(id, state.selectedDate, done) },
                            modifier = Modifier.fillMaxSize()
                        )
                        HabitTab.WEEKLY -> WeeklyView(
                            weekStart = state.weekStart,
                            habits = state.weeklyHabits,
                            onToggleDay = viewModel::toggleHabit,
                            onPrevWeek = { viewModel.changeWeek(forward = false) },
                            onNextWeek = { viewModel.changeWeek(forward = true) },
                            modifier = Modifier.fillMaxSize()
                        )
                        HabitTab.MONTHLY -> MonthlyView(
                            monthAnchor = state.monthAnchor,
                            habits = state.monthlyHabits,
                            onToggleDay = viewModel::toggleHabit,
                            onPrevMonth = { viewModel.changeMonth(forward = false) },
                            onNextMonth = { viewModel.changeMonth(forward = true) },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }

    if (showAddHabit) {
        AddHabitBottomSheet(
            routines = state.routines,
            onDismiss = { showAddHabit = false },
            onCreate = { name, routineId, days ->
                viewModel.createHabit(name, routineId, days)
                showAddHabit = false
            },
            onRequestNewRoutine = {
                showAddHabit = false
                showAddRoutine = true
            }
        )
    }

    if (showAddRoutine) {
        AddRoutineBottomSheet(
            onDismiss = { showAddRoutine = false },
            onCreate = { name ->
                viewModel.createRoutine(name)
                showAddRoutine = false
            }
        )
    }
}

@Composable
private fun HabitTopTabs(
    selected: HabitTab,
    onSelect: (HabitTab) -> Unit
) {
    val tabs = listOf(HabitTab.TODAY to "Today", HabitTab.WEEKLY to "Weekly", HabitTab.MONTHLY to "Monthly")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .background(HabitColors.Surface, RoundedCornerShape(10.dp))
            .padding(4.dp)
    ) {
        tabs.forEach { (tab, label) ->
            val isSelected = tab == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { onSelect(tab) }
                    )
                    .background(
                        color = if (isSelected) HabitColors.Background else Color.Transparent,
                        shape = RoundedCornerShape(8.dp)
                    )
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    fontSize = 13.sp,
                    fontWeight = if (isSelected) FontWeight.Medium else FontWeight.Normal,
                    color = if (isSelected) HabitColors.TextPrimary else HabitColors.TextSecondary
                )
            }
        }
    }
}
