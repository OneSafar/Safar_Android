package com.parmaracademy.safar.habits.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Circular tap target that animates fill/scale on completion. Target: 150-200ms. */
@Composable
fun HabitCheckButton(
    completed: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (completed) 1f else 0.92f,
        animationSpec = tween(durationMillis = 180),
        label = "check-scale"
    )
    Box(
        modifier = modifier
            .size(22.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onToggle
            )
            .background(
                color = if (completed) HabitColors.CheckDone else Color.Transparent,
                shape = CircleShape
            )
            .border(
                width = 1.5.dp,
                color = if (completed) HabitColors.CheckDone else HabitColors.OutlineStrong,
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        if (completed) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "Completed",
                tint = HabitColors.CheckDoneOn,
                modifier = Modifier.size((14 * scale).dp)
            )
        }
    }
}

/** A single habit line: check button + name, name strikes through when done. */
@Composable
fun HabitRow(
    name: String,
    completed: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onToggle
            )
            .padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HabitCheckButton(completed = completed, onToggle = onToggle)
        Box(modifier = Modifier.padding(start = 10.dp)) {
            Text(
                text = name,
                fontSize = 14.sp,
                color = if (completed) HabitColors.TextSecondary else HabitColors.TextPrimary,
                textDecoration = if (completed) TextDecoration.LineThrough else null
            )
        }
    }
}

/** Pastel section header for a routine group, e.g. "Morning routine". */
@Composable
fun RoutineSectionHeader(
    title: String,
    accentIndex: Int,
    modifier: Modifier = Modifier
) {
    val bg = HabitColors.PastelAccents[accentIndex % HabitColors.PastelAccents.size]
    val fg = HabitColors.PastelText[accentIndex % HabitColors.PastelText.size]
    Box(
        modifier = modifier
            .background(bg, RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = fg
        )
    }
}
