package com.parmaracademy.safar.habits.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.parmaracademy.safar.habits.data.HabitWithCompletion
import com.parmaracademy.safar.habits.data.RoutineEntity
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun TodayView(
    date: LocalDate,
    routines: List<RoutineEntity>,
    habits: List<HabitWithCompletion>,
    onToggle: (habitId: Long, completed: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val byRoutine = habits.groupBy { it.habit.routineId }
    val standalone = byRoutine[null].orEmpty()

    LazyColumn(
        modifier = modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)) {
                Text(
                    text = "Today",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Medium,
                    color = HabitColors.TextPrimary
                )
                Text(
                    text = date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault())),
                    fontSize = 13.sp,
                    color = HabitColors.TextSecondary
                )
            }
        }

        routines.forEachIndexed { index, routine ->
            val routineHabits = byRoutine[routine.id].orEmpty()
            if (routineHabits.isNotEmpty()) {
                item {
                    RoutineSectionHeader(
                        title = routine.name,
                        accentIndex = index,
                        modifier = Modifier.padding(top = 10.dp, bottom = 6.dp)
                    )
                }
                items(routineHabits, key = { it.habit.id }) { item ->
                    HabitRow(
                        name = item.habit.name,
                        completed = item.completed,
                        onToggle = { onToggle(item.habit.id, item.completed) }
                    )
                }
            }
        }

        if (standalone.isNotEmpty()) {
            item {
                RoutineSectionHeader(
                    title = "Other habits",
                    accentIndex = routines.size,
                    modifier = Modifier.padding(top = 10.dp, bottom = 6.dp)
                )
            }
            items(standalone, key = { it.habit.id }) { item ->
                HabitRow(
                    name = item.habit.name,
                    completed = item.completed,
                    onToggle = { onToggle(item.habit.id, item.completed) }
                )
            }
        }
    }
}
