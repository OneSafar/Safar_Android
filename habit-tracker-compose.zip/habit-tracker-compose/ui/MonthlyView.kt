package com.parmaracademy.safar.habits.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as columnItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.parmaracademy.safar.habits.data.HabitWithCompletions
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun MonthlyView(
    monthAnchor: LocalDate,
    habits: List<HabitWithCompletions>,
    onToggleDay: (habitId: Long, date: LocalDate, completed: Boolean) -> Unit,
    onPrevMonth: () -> Unit,
    onNextMonth: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(modifier = modifier.padding(horizontal = 16.dp)) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onPrevMonth) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Previous month")
                }
                Text(
                    text = monthAnchor.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault())),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = HabitColors.TextPrimary
                )
                IconButton(onClick = onNextMonth) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Next month")
                }
            }
        }
        columnItems(habits, key = { it.habit.id }) { hc ->
            MonthlyHabitCard(
                name = hc.habit.name,
                completionByDate = hc.completionByDate,
                onToggle = { date, completed -> onToggleDay(hc.habit.id, date, completed) },
                modifier = Modifier.padding(bottom = 14.dp)
            )
        }
    }
}

@Composable
private fun MonthlyHabitCard(
    name: String,
    completionByDate: Map<LocalDate, Boolean>,
    onToggle: (LocalDate, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val days = completionByDate.keys.sorted()
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(HabitColors.Surface, RoundedCornerShape(12.dp))
            .border(0.5.dp, HabitColors.Outline, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Text(
            text = name,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = HabitColors.TextPrimary,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            modifier = Modifier.fillMaxWidth()
        ) {
            gridItems(days) { day ->
                MonthlyDayCell(
                    day = day,
                    completed = completionByDate[day] == true,
                    onClick = { onToggle(day, completionByDate[day] == true) }
                )
            }
        }
    }
}

@Composable
private fun MonthlyDayCell(day: LocalDate, completed: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .padding(2.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .background(
                color = if (completed) HabitColors.CheckDone else Color.Transparent,
                shape = RoundedCornerShape(5.dp)
            )
            .border(
                width = 1.dp,
                color = if (completed) HabitColors.CheckDone else HabitColors.Outline,
                shape = RoundedCornerShape(5.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = day.dayOfMonth.toString(),
            fontSize = 10.sp,
            color = if (completed) HabitColors.CheckDoneOn else HabitColors.TextSecondary
        )
    }
}
