package com.parmaracademy.safar.habits.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddRoutineBottomSheet(
    onDismiss: () -> Unit,
    onCreate: (name: String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState()
    var name by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            Text(
                text = "New routine",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = HabitColors.TextPrimary,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            Text("Name", fontSize = 12.sp, color = HabitColors.TextSecondary)
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    if (error != null && it.isNotBlank()) error = null
                },
                placeholder = { Text("Morning routine") },
                isError = error != null,
                supportingText = error?.let { { Text(it) } },
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 16.dp)
            )
            Button(
                onClick = {
                    if (name.isBlank()) {
                        error = "Enter a routine name"
                        return@Button
                    }
                    onCreate(name.trim())
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Create")
            }
        }
    }
}
