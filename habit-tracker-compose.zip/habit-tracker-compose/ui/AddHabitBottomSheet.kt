package com.parmaracademy.safar.habits.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.parmaracademy.safar.habits.data.RoutineEntity
import java.time.DayOfWeek

private val ALL_DAYS = DayOfWeek.entries.toList()
private val DAY_LABELS = listOf("M", "T", "W", "T", "F", "S", "S")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddHabitBottomSheet(
    routines: List<RoutineEntity>,
    onDismiss: () -> Unit,
    onCreate: (name: String, routineId: Long?, days: Set<DayOfWeek>) -> Unit,
    onRequestNewRoutine: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState()
    var name by remember { mutableStateOf("") }
    var selectedRoutine by remember { mutableStateOf<RoutineEntity?>(null) }
    var routineMenuExpanded by remember { mutableStateOf(false) }
    var everyDay by remember { mutableStateOf(true) }
    var selectedDays by remember { mutableStateOf(ALL_DAYS.toSet()) }
    var nameError by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            Text(
                text = "New habit",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = HabitColors.TextPrimary,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Text("Habit name", fontSize = 12.sp, color = HabitColors.TextSecondary)
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    if (nameError != null && it.isNotBlank()) nameError = null
                },
                placeholder = { Text("Drink water") },
                isError = nameError != null,
                supportingText = nameError?.let { { Text(it) } },
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 16.dp)
            )

            Text("Routine", fontSize = 12.sp, color = HabitColors.TextSecondary)
            Box(modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(HabitColors.Background, RoundedCornerShape(8.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = { routineMenuExpanded = true }
                        )
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = selectedRoutine?.name ?: "Standalone (no routine)",
                        fontSize = 14.sp,
                        color = HabitColors.TextPrimary
                    )
                    Text("▾", color = HabitColors.TextSecondary)
                }
                DropdownMenu(
                    expanded = routineMenuExpanded,
                    onDismissRequest = { routineMenuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Standalone (no routine)") },
                        onClick = { selectedRoutine = null; routineMenuExpanded = false }
                    )
                    routines.forEach { routine ->
                        DropdownMenuItem(
                            text = { Text(routine.name) },
                            onClick = { selectedRoutine = routine; routineMenuExpanded = false }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("+ New routine…") },
                        onClick = {
                            routineMenuExpanded = false
                            onRequestNewRoutine()
                        }
                    )
                }
            }

            Text("Repeat", fontSize = 12.sp, color = HabitColors.TextSecondary)
            Row(
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                RepeatChip(label = "Every day", selected = everyDay) {
                    everyDay = true
                    selectedDays = ALL_DAYS.toSet()
                }
                RepeatChip(label = "Custom", selected = !everyDay) {
                    everyDay = false
                }
            }
            if (!everyDay) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ALL_DAYS.forEachIndexed { i, day ->
                        val isOn = day in selectedDays
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = {
                                        selectedDays = if (isOn) selectedDays - day else selectedDays + day
                                    }
                                )
                                .background(
                                    color = if (isOn) HabitColors.CheckDone else HabitColors.Background,
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = DAY_LABELS[i],
                                fontSize = 12.sp,
                                color = if (isOn) HabitColors.CheckDoneOn else HabitColors.TextSecondary
                            )
                        }
                    }
                }
            }

            Button(
                onClick = {
                    if (name.isBlank()) {
                        nameError = "Enter a habit name"
                        return@Button
                    }
                    val days = if (everyDay) ALL_DAYS.toSet() else selectedDays
                    onCreate(name.trim(), selectedRoutine?.id, days)
                },
                modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
            ) {
                Text("Add")
            }
        }
    }
}

@Composable
private fun RepeatChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .background(
                color = if (selected) HabitColors.CheckDone else HabitColors.Background,
                shape = RoundedCornerShape(20.dp)
            )
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = if (selected) HabitColors.CheckDoneOn else HabitColors.TextSecondary
        )
    }
}
