package com.parmaracademy.safar.habits.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.parmaracademy.safar.habits.data.HabitWithCompletions
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun WeeklyView(
    weekStart: LocalDate,
    habits: List<HabitWithCompletions>,
    onToggleDay: (habitId: Long, date: LocalDate, completed: Boolean) -> Unit,
    onPrevWeek: () -> Unit,
    onNextWeek: () -> Unit,
    modifier: Modifier = Modifier
) {
    val weekEnd = weekStart.plusDays(6)
    val monthFmt = DateTimeFormatter.ofPattern("MMM d", Locale.getDefault())
    val days = (0..6).map { weekStart.plusDays(it.toLong()) }
    val dayLabels = listOf("M", "T", "W", "T", "F", "S", "S")

    LazyColumn(modifier = modifier.padding(horizontal = 16.dp)) {
        item {
            WeekNavHeader(
                label = "${weekStart.format(monthFmt)} – ${weekEnd.format(monthFmt)}",
                onPrev = onPrevWeek,
                onNext = onNextWeek
            )
        }
        item {
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Box(modifier = Modifier.weight(1.6f))
                dayLabels.forEach { label ->
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text(label, fontSize = 11.sp, color = HabitColors.TextSecondary)
                    }
                }
            }
        }
        items(habits, key = { it.habit.id }) { hc ->
            WeeklyHabitRow(
                name = hc.habit.name,
                days = days,
                completionByDate = hc.completionByDate,
                onToggle = { date, completed -> onToggleDay(hc.habit.id, date, completed) }
            )
        }
    }
}

@Composable
private fun WeekNavHeader(label: String, onPrev: () -> Unit, onNext: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onPrev) {
            Icon(Icons.Default.ChevronLeft, contentDescription = "Previous week")
        }
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = HabitColors.TextPrimary)
        IconButton(onClick = onNext) {
            Icon(Icons.Default.ChevronRight, contentDescription = "Next week")
        }
    }
}

@Composable
private fun WeeklyHabitRow(
    name: String,
    days: List<LocalDate>,
    completionByDate: Map<LocalDate, Boolean>,
    onToggle: (LocalDate, Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.weight(1.6f)) {
            Text(name, fontSize = 13.sp, color = HabitColors.TextPrimary)
        }
        days.forEach { day ->
            val done = completionByDate[day] == true
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                WeeklyDayCell(completed = done, onClick = { onToggle(day, done) })
            }
        }
    }
}

@Composable
private fun WeeklyDayCell(completed: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(18.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .background(
                color = if (completed) HabitColors.CheckDone else androidx.compose.ui.graphics.Color.Transparent,
                shape = CircleShape
            )
            .border(
                width = 1.5.dp,
                color = if (completed) HabitColors.CheckDone else HabitColors.OutlineStrong,
                shape = CircleShape
            )
    )
}
