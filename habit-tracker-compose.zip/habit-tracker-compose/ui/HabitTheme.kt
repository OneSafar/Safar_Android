package com.parmaracademy.safar.habits.ui

import androidx.compose.ui.graphics.Color

/**
 * Fixed light-mode palette per spec: off-white paper background, dark text,
 * thin outlines, pastel section accents, no gradients/heavy elevation.
 */
object HabitColors {
    val Background = Color(0xFFFFFDF6)   // off-white paper
    val Surface = Color(0xFFFFFFFF)
    val TextPrimary = Color(0xFF1E1B16)
    val TextSecondary = Color(0xFF8A8477)
    val Outline = Color(0xFFE7E2D4)
    val OutlineStrong = Color(0xFFD8D2C0)
    val CheckDone = Color(0xFF4C7A5E)     // muted sage green
    val CheckDoneOn = Color(0xFFFFFFFF)

    // Pastel section header accents, cycled per routine
    val PastelAccents = listOf(
        Color(0xFFF4E3D3), // peach
        Color(0xFFE1EAE0), // sage
        Color(0xFFE4E1F0), // lavender
        Color(0xFFF0E1E6)  // blush
    )
    val PastelText = listOf(
        Color(0xFF8A5A2B),
        Color(0xFF3E5F49),
        Color(0xFF4B4680),
        Color(0xFF7A3D51)
    )
}
