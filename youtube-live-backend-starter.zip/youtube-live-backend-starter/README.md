# YouTube Live Backend Starter

Node.js + Express + MongoDB starter backend for an edtech Android app that embeds YouTube Live sessions.

## MVP flow

1. Teacher/admin schedules a YouTube Live event manually in YouTube Studio.
2. Teacher uses OBS or Streamlabs to stream to YouTube.
3. Backend stores course/session metadata and the YouTube video ID.
4. Android app calls `GET /api/live-sessions/:id` and embeds the returned `youtubeEmbedUrl`.

## Setup

```bash
cp .env.example .env
npm install
npm run dev
```

Start MongoDB locally or update `MONGODB_URI` in `.env`.

## Auth

This starter expects a JWT:

```json
{
  "sub": "USER_OBJECT_ID",
  "role": "student|teacher|admin",
  "enrolledCourseIds": ["COURSE_OBJECT_ID"]
}
```

Replace `src/middleware/auth.js` with your app's real auth middleware.

## Endpoints

### Create live session

`POST /api/live-sessions` — teacher/admin only

```json
{
  "title": "Physics Live Class - Gravitation",
  "description": "Chapter revision and doubt solving",
  "courseId": "665111111111111111111111",
  "teacherId": "665222222222222222222222",
  "scheduledStartAt": "2026-06-01T13:30:00.000Z",
  "scheduledEndAt": "2026-06-01T14:30:00.000Z",
  "youtubeUrlOrId": "https://www.youtube.com/watch?v=VIDEO_ID",
  "isChatEnabled": true,
  "resources": [
    { "label": "Class notes", "url": "https://example.com/notes.pdf" }
  ]
}
```

### List sessions

`GET /api/live-sessions?courseId=665111111111111111111111&status=scheduled`

### Get playback details

`GET /api/live-sessions/:id`

Returns safe student-facing playback data. It never returns YouTube stream keys.

### Update status

`PATCH /api/live-sessions/:id/status`

```json
{ "status": "live" }
```

## Production checklist

- Replace auth stub with real app auth.
- Check enrollment using your real Course/Enrollment collection.
- Add rate limiting and audit logs for teacher/admin routes.
- Add FCM notification trigger when a session changes to `live`.
- Add server-side job to mark sessions ended after time passes.
- Store analytics events separately: join, leave, watch duration, errors.
