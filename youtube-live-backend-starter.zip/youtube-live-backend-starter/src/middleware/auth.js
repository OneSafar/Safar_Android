import jwt from 'jsonwebtoken';
import { httpError } from '../utils/httpError.js';

// Replace this with your existing auth middleware if your app already has login.
export function requireAuth(req, _res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) return next(httpError(401, 'Missing bearer token'));

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = {
      id: payload.sub,
      role: payload.role || 'student',
      enrolledCourseIds: payload.enrolledCourseIds || []
    };
    next();
  } catch (_err) {
    next(httpError(401, 'Invalid or expired token'));
  }
}

export function requireTeacherOrAdmin(req, _res, next) {
  if (!req.user) return next(httpError(401, 'Unauthorized'));
  if (['teacher', 'admin'].includes(req.user.role)) return next();
  return next(httpError(403, 'Teacher or admin role required'));
}

export function requireCourseAccess(session, user) {
  if (!user) throw httpError(401, 'Unauthorized');
  if (['teacher', 'admin'].includes(user.role)) return;

  const courseId = String(session.courseId);
  const hasAccess = user.enrolledCourseIds.map(String).includes(courseId);
  if (!hasAccess) throw httpError(403, 'You are not enrolled in this course');
}
