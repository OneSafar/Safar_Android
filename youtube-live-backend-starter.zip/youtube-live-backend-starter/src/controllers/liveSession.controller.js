import { z } from 'zod';
import { LiveSession } from '../models/LiveSession.js';
import { httpError } from '../utils/httpError.js';
import { extractYouTubeVideoId } from '../utils/youtube.js';
import { requireCourseAccess } from '../middleware/auth.js';

const objectId = z.string().regex(/^[a-fA-F0-9]{24}$/);

const createSchema = z.object({
  title: z.string().min(3).max(120),
  description: z.string().max(2000).optional().default(''),
  courseId: objectId,
  teacherId: objectId,
  scheduledStartAt: z.string().datetime(),
  scheduledEndAt: z.string().datetime().optional(),
  youtubeUrlOrId: z.string().min(1),
  isChatEnabled: z.boolean().optional().default(true),
  resources: z
    .array(z.object({ label: z.string().min(1).max(80), url: z.string().url() }))
    .optional()
    .default([])
});

const updateSchema = createSchema.partial().extend({
  status: z.enum(['scheduled', 'live', 'ended', 'cancelled']).optional(),
  isRecordingAvailable: z.boolean().optional(),
  recordingVideoId: z.string().optional().nullable()
});

export async function createLiveSession(req, res, next) {
  try {
    const body = createSchema.parse(req.body);
    const youtubeVideoId = extractYouTubeVideoId(body.youtubeUrlOrId);
    if (!youtubeVideoId) throw httpError(400, 'Invalid YouTube video ID or URL');

    const session = await LiveSession.create({
      ...body,
      youtubeVideoId,
      scheduledStartAt: new Date(body.scheduledStartAt),
      scheduledEndAt: body.scheduledEndAt ? new Date(body.scheduledEndAt) : undefined,
      createdBy: req.user.id
    });

    res.status(201).json(session.toStudentJson());
  } catch (err) {
    next(err);
  }
}

export async function listLiveSessions(req, res, next) {
  try {
    const { courseId, status, from, to, limit = 20 } = req.query;
    const query = {};

    if (courseId) query.courseId = courseId;
    if (status) query.status = status;
    if (from || to) {
      query.scheduledStartAt = {};
      if (from) query.scheduledStartAt.$gte = new Date(from);
      if (to) query.scheduledStartAt.$lte = new Date(to);
    }

    const sessions = await LiveSession.find(query)
      .sort({ scheduledStartAt: 1 })
      .limit(Math.min(Number(limit) || 20, 100));

    res.json(sessions.map((session) => session.toStudentJson()));
  } catch (err) {
    next(err);
  }
}

export async function getLiveSession(req, res, next) {
  try {
    const session = await LiveSession.findById(req.params.id);
    if (!session) throw httpError(404, 'Live session not found');

    requireCourseAccess(session, req.user);
    res.json(session.toStudentJson());
  } catch (err) {
    next(err);
  }
}

export async function updateLiveSession(req, res, next) {
  try {
    const body = updateSchema.parse(req.body);

    if (body.youtubeUrlOrId) {
      const youtubeVideoId = extractYouTubeVideoId(body.youtubeUrlOrId);
      if (!youtubeVideoId) throw httpError(400, 'Invalid YouTube video ID or URL');
      body.youtubeVideoId = youtubeVideoId;
      delete body.youtubeUrlOrId;
    }

    if (body.scheduledStartAt) body.scheduledStartAt = new Date(body.scheduledStartAt);
    if (body.scheduledEndAt) body.scheduledEndAt = new Date(body.scheduledEndAt);

    const session = await LiveSession.findByIdAndUpdate(req.params.id, body, {
      new: true,
      runValidators: true
    });

    if (!session) throw httpError(404, 'Live session not found');
    res.json(session.toStudentJson());
  } catch (err) {
    next(err);
  }
}

export async function updateLiveSessionStatus(req, res, next) {
  try {
    const schema = z.object({ status: z.enum(['scheduled', 'live', 'ended', 'cancelled']) });
    const { status } = schema.parse(req.body);

    const session = await LiveSession.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true, runValidators: true }
    );

    if (!session) throw httpError(404, 'Live session not found');
    res.json(session.toStudentJson());
  } catch (err) {
    next(err);
  }
}
