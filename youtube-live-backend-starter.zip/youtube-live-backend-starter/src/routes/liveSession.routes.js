import { Router } from 'express';
import {
  createLiveSession,
  getLiveSession,
  listLiveSessions,
  updateLiveSession,
  updateLiveSessionStatus
} from '../controllers/liveSession.controller.js';
import { requireAuth, requireTeacherOrAdmin } from '../middleware/auth.js';

const router = Router();

router.use(requireAuth);

router.get('/', listLiveSessions);
router.get('/:id', getLiveSession);
router.post('/', requireTeacherOrAdmin, createLiveSession);
router.patch('/:id', requireTeacherOrAdmin, updateLiveSession);
router.patch('/:id/status', requireTeacherOrAdmin, updateLiveSessionStatus);

export default router;
