const YOUTUBE_ID_REGEX = /^[a-zA-Z0-9_-]{11}$/;

export function extractYouTubeVideoId(input) {
  if (!input || typeof input !== 'string') return null;
  const value = input.trim();

  if (YOUTUBE_ID_REGEX.test(value)) return value;

  try {
    const url = new URL(value);

    if (url.hostname.includes('youtu.be')) {
      const id = url.pathname.replace('/', '').split('/')[0];
      return YOUTUBE_ID_REGEX.test(id) ? id : null;
    }

    if (url.hostname.includes('youtube.com')) {
      const watchId = url.searchParams.get('v');
      if (watchId && YOUTUBE_ID_REGEX.test(watchId)) return watchId;

      const parts = url.pathname.split('/').filter(Boolean);
      const embedIndex = parts.indexOf('embed');
      if (embedIndex >= 0 && parts[embedIndex + 1] && YOUTUBE_ID_REGEX.test(parts[embedIndex + 1])) {
        return parts[embedIndex + 1];
      }

      const liveIndex = parts.indexOf('live');
      if (liveIndex >= 0 && parts[liveIndex + 1] && YOUTUBE_ID_REGEX.test(parts[liveIndex + 1])) {
        return parts[liveIndex + 1];
      }
    }
  } catch (_err) {
    return null;
  }

  return null;
}

export function buildYouTubeUrls(videoId) {
  if (!videoId) return { watchUrl: null, embedUrl: null, thumbnailUrl: null };

  return {
    watchUrl: `https://www.youtube.com/watch?v=${videoId}`,
    embedUrl: `https://www.youtube.com/embed/${videoId}?enablejsapi=1&playsinline=1&rel=0`,
    thumbnailUrl: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
  };
}
