import 'dotenv/config';
import { createApp } from './app.js';
import { connectDb } from './config/db.js';

const port = process.env.PORT || 8080;

await connectDb();
const app = createApp();

app.listen(port, () => {
  console.log(`Live session API running on http://localhost:${port}`);
});
