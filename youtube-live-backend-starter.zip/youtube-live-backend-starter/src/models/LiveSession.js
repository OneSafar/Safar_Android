import mongoose from 'mongoose';
import { buildYouTubeUrls } from '../utils/youtube.js';

const LiveSessionSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, default: '', trim: true, maxlength: 2000 },
    courseId: { type: mongoose.Schema.Types.ObjectId, required: true, index: true },
    teacherId: { type: mongoose.Schema.Types.ObjectId, required: true, index: true },
    scheduledStartAt: { type: Date, required: true, index: true },
    scheduledEndAt: { type: Date },
    status: {
      type: String,
      enum: ['scheduled', 'live', 'ended', 'cancelled'],
      default: 'scheduled',
      index: true
    },
    youtubeVideoId: { type: String, required: true, trim: true },
    isChatEnabled: { type: Boolean, default: true },
    isRecordingAvailable: { type: Boolean, default: false },
    recordingVideoId: { type: String, default: null },
    resources: [
      {
        label: { type: String, required: true, trim: true },
        url: { type: String, required: true, trim: true }
      }
    ],
    createdBy: { type: mongoose.Schema.Types.ObjectId, required: true }
  },
  { timestamps: true }
);

LiveSessionSchema.index({ courseId: 1, scheduledStartAt: -1 });
LiveSessionSchema.index({ status: 1, scheduledStartAt: 1 });

LiveSessionSchema.methods.toStudentJson = function toStudentJson() {
  const urls = buildYouTubeUrls(this.youtubeVideoId);
  return {
    id: this._id,
    title: this.title,
    description: this.description,
    courseId: this.courseId,
    teacherId: this.teacherId,
    scheduledStartAt: this.scheduledStartAt,
    scheduledEndAt: this.scheduledEndAt,
    status: this.status,
    youtubeVideoId: this.youtubeVideoId,
    youtubeEmbedUrl: urls.embedUrl,
    youtubeWatchUrl: urls.watchUrl,
    thumbnailUrl: urls.thumbnailUrl,
    isChatEnabled: this.isChatEnabled,
    isRecordingAvailable: this.isRecordingAvailable,
    recordingVideoId: this.recordingVideoId,
    resources: this.resources,
    serverTime: new Date().toISOString()
  };
};

export const LiveSession = mongoose.model('LiveSession', LiveSessionSchema);
