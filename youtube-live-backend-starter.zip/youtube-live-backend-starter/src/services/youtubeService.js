/*
Optional future automation.

For the MVP, create the YouTube Live manually in YouTube Studio and paste the video URL/ID
into POST /api/live-sessions.

Later, you can automate with YouTube Live Streaming API:
1. OAuth teacher/admin Google account that owns the YouTube channel.
2. liveBroadcasts.insert -> create scheduled broadcast.
3. liveStreams.insert -> create stream and receive ingestionInfo.
4. liveBroadcasts.bind -> bind broadcast to stream.
5. Send ingestionInfo.rtmpsIngestionAddress + streamName to OBS/Streamlabs.

Do NOT send stream keys to student apps.
*/
export async function createYouTubeBroadcastPlaceholder() {
  throw new Error('YouTube API automation is intentionally not implemented in MVP starter.');
}
